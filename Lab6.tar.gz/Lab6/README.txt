compile with
g++ -g BST.cpp -std=c++11 -o Lab6.out

I made my own BST that only parses strings from the text file. you can use the bst to hold anything as long as BinaryNode is changed to hold the correct type of data.
